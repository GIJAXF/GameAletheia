using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using GameAletheiaCross.ViewModels;

namespace GameAletheiaCross.Views;

public partial class DialogueView : UserControl
{
    public DialogueView()
    {
        InitializeComponent();
    }
}
