using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using GameAletheiaCross.ViewModels;

namespace GameAletheiaCross.Views;

public partial class LoadGameView : UserControl
{
    public LoadGameView()
    {
        InitializeComponent();
    }
}