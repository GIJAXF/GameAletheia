using Avalonia.Controls;

namespace GameAletheiaCross.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
