using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using GameAletheiaCross.ViewModels;

namespace GameAletheiaCross.Views;

public partial class RankingView : UserControl
{
    public RankingView()
    {
        InitializeComponent();
    }
}