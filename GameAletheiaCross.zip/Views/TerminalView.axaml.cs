using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using GameAletheiaCross.ViewModels;

namespace GameAletheiaCross.Views;

public partial class TerminalView : UserControl
{
    public TerminalView()
    {
        InitializeComponent();
    }
}
