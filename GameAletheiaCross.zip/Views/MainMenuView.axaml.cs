using Avalonia.Controls;

namespace GameAletheiaCross.Views
{
    public partial class MainMenuView : UserControl
    {
        public MainMenuView()
        {
            InitializeComponent();
        }
    }
}