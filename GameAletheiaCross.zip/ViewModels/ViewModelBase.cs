using ReactiveUI;

namespace GameAletheiaCross.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}